"""
NumPy ndarray vs Torch Tensor -- after .

Sketch:
  1. So what are NumPy and Torch?
"""

import matplotlib.pyplot as plt
from _config import (
    FS_FIGURE_TITLE,
    FS_AX_TITLE,
    FS_AXIS,
    FS_TICK,
    FS_ANNOT,
    FS_LEGEND,
    FIGURE_DPI,
    apply_rcparams,
    screen_figsize,
    run_slide_deck,
)
apply_rcparams(plt)
import matplotlib.patches as patches
import numpy as np

np.random.seed(42)


def new_figure(*args, **kwargs):
    kwargs.setdefault('figsize', screen_figsize())
    kwargs.setdefault('dpi', FIGURE_DPI)
    return plt.subplots(*args, **kwargs)


def blank_slide(ax):
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 8)
    ax.axis('off')


def round_box(ax, x, y, w, h, facecolor, edgecolor='0.2', lw=2.0):
    rect = patches.FancyBboxPatch(
        (x, y), w, h,
        boxstyle='round,pad=0.02,rounding_size=0.15',
        facecolor=facecolor, edgecolor=edgecolor, linewidth=lw,
    )
    ax.add_patch(rect)
    return rect


def arrow(ax, x1, y1, x2, y2, color='0.25', lw=2.5):
    ax.annotate(
        '', xy=(x2, y2), xytext=(x1, y1),
        arrowprops=dict(arrowstyle='->', color=color, lw=lw,
                        mutation_scale=18),
    )


# Palette
C_DARK = '#1a5276'
C_NEW = '#d6eaf8'
C_OK = '#1e8449'
C_ACCENT = '#c0392b'
C_MUTE = '#f4f6f7'
C_GOAL = '#d4edda'
C_OLD = '#fce4d6'

# blank_slide axes ~0..12 x 0..8: ~1cm ≈ 0.673 data units (y)
CM_Y = 0.673


# FIGURE 1: So what are NumPy and Torch?
# -------------------------------------------------------
def build_step_1():
    fig1, ax1 = new_figure()
    fig1.suptitle(
        'Step 1: So what are NumPy and Torch?',
        fontsize=FS_FIGURE_TITLE - 2, fontweight='bold',
    )
    blank_slide(ax1)

    round_box(ax1, 0.5, 6.55, 11.0, 1.15, C_DARK, C_DARK, lw=0)
    ax1.text(
        6.0, 7.1,
        'Two libraries for numbers in arrays -- same spirit, different engine.',
        ha='center', va='center', fontsize=FS_AX_TITLE - 2,
        fontweight='bold', color='white',
    )

    # NumPy
    round_box(ax1, 0.5, 3.55, 5.3, 2.7, C_NEW, '#2874a6', lw=2.2)
    ax1.text(
        3.15, 5.9, 'NumPy  --  ndarray',
        ha='center', va='center', fontsize=FS_AX_TITLE - 2,
        fontweight='bold', color=C_DARK,
    )
    ax1.text(
        3.15, 5.25,
        'CPU array. No autograd. Data prep & science.',
        ha='center', va='center', fontsize=FS_ANNOT,
    )
    ax1.text(
        3.15, 4.15,
        'import numpy as np\n\n'
        'a = np.array([[1., 2.],\n'
        '              [3., 4.]])',
        ha='center', va='center', fontsize=FS_ANNOT + 1,
        family='monospace',
        bbox=dict(boxstyle='round,pad=0.4', facecolor='white',
                  edgecolor='#2874a6', alpha=0.98),
    )

    # Torch
    round_box(ax1, 6.2, 3.55, 5.3, 2.7, C_GOAL, C_OK, lw=2.2)
    ax1.text(
        8.85, 5.9, 'Torch  --  Tensor',
        ha='center', va='center', fontsize=FS_AX_TITLE - 2,
        fontweight='bold', color=C_OK,
    )
    ax1.text(
        8.85, 5.25,
        'CPU/GPU array + optional gradient tape.',
        ha='center', va='center', fontsize=FS_ANNOT,
    )
    ax1.text(
        8.85, 4.15,
        'import torch\n\n'
        't = torch.tensor([[1., 2.],\n'
        '                  [3., 4.]])',
        ha='center', va='center', fontsize=FS_ANNOT + 1,
        family='monospace',
        bbox=dict(boxstyle='round,pad=0.4', facecolor='white',
                  edgecolor=C_OK, alpha=0.98),
    )

    # Difference strip
    round_box(ax1, 0.5, 1.55, 11.0, 1.7, C_MUTE, '0.45', lw=1.6)
    ax1.text(
        6.0, 2.85, 'ndarray vs Tensor -- the practical difference',
        ha='center', va='center', fontsize=FS_ANNOT + 2,
        fontweight='bold', color=C_DARK,
    )
    ax1.text(
        6.0, 2.05,
        'A Tensor is an array plus device + optional gradient tape.\n'
        'Bridge either way:  '
        r'$\mathrm{torch.from\_numpy}(a)$'
        '   /   '
        r'$t.detach().cpu().numpy()$',
        ha='center', va='center', fontsize=FS_ANNOT + 1,
    )

    # Bottom two textboxes moved down 1.5 cm.
    _s1_bot_dy = 1.5 * CM_Y
    _s1_y_yellow = 1.0 - _s1_bot_dy
    _s1_y_warn = 0.15 - _s1_bot_dy
    ax1.set_ylim(min(_s1_y_warn, 0.0) - 0.2, 8)
    round_box(ax1, 0.5, _s1_y_yellow, 11.0, 0.9, 'lightyellow', '0.55', lw=1.6)
    ax1.text(
        6.0, _s1_y_yellow + 0.45,
        'Same mental model: operate on whole arrays, not one scalar at a time.\n'
        'NumPy explores and prepares data.  Torch learns from it.',
        ha='center', va='center', fontsize=FS_ANNOT + 1, fontweight='bold',
    )

    round_box(ax1, 0.5, _s1_y_warn, 11.0, 0.7, '#f8d7da', C_ACCENT, lw=1.8)
    ax1.text(
        6.0, _s1_y_warn + 0.35,
        'Study, independently, the indexing and operations of arrays and tensors.',
        ha='center', va='center', fontsize=FS_ANNOT + 1, fontweight='bold',
        color=C_ACCENT,
    )
    return fig1


run_slide_deck([build_step_1])


# -------------------------------------------------------
# KEY INSIGHTS
# -------------------------------------------------------
print("\n" + "=" * 60)
print("NUMPY VS TORCH")
print("=" * 60)
print("""
NumPy vs Torch (Step 1):
  ndarray: CPU, no autograd.  Tensor: CPU/GPU + optional gradient tape.
  Bridge: torch.from_numpy(a) / t.detach().cpu().numpy().
  Same mental model: operate on whole arrays, not one scalar at a time.

Study, independently, the indexing and operations of arrays and tensors.

, 
""")
